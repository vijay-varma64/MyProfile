
var typed = new Typed(".typing", {
    strings: ["", "Web Designer", "web Developer", "UI/UX Designer", "Freelancer"],
    typeSpeed: 180,
    BackSpeed: 60,
    loop: true
})
var typed = new Typed(".typingg", {
    strings: ["", "Web Designer", "web Developer", "UI/UX Designer", "Freelancer"],
    typeSpeed: 60,
    BackSpeed: 60,
    loop: true
})